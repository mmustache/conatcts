<h2 align="center">How to Use 🤔</h2>

- Clone this repository:  
  $ `git clone https://github.com/dickymuliafiqri/Contacts contacts`

- Enter in directory:  
  $ `cd contacts`

- For install dependencies:  
  $ `flutter packages get`

- Put `contact_api` inside `C://xampp/htdocs` folder

- Run the app:  
  $ `flutter run`
